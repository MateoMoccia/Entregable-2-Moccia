// let variable = "cambiante"

// const constante = "no cambiante"


let bienvenida = document.createElement ("h1");
bienvenida.textContent = "Bienvenido a nuestra tienda de cookies"

let subtitulo = document.createElement ("p")
subtitulo.className = "claseSubtitulo"
subtitulo.textContent = "Aca podras encontrar las mejores cookies del pais y a un precio irresistible"

const header = document.getElementById ("header")
header.appendChild (bienvenida)
header.appendChild (subtitulo)

// <----------------------------------------------------------------->
const menuDeCookies = [
{
    id: 1,
            Imagen:"/img/Screenshot 2024-10-21 194354.png",
    Producto: "Clasic one",
    Precio: 3000,
    Calorias:"150",
    Descripcion: "Cookie dorada de vainilla con chips de chocolate semiamargo, receta tradicional americana",
},
{
        id: 2,
                Imagen:"/img/Screenshot 2024-10-21 194500.png",
    Producto: "ChocoMood",
    Precio: 3200,
    Calorias: "200",
    Descripcion: "Masa de chocolate, chips de chocolate con leche y centro de Nutella fundida",
},
{
        id: 3,
                Imagen:"/img/Screenshot 2024-10-21 194529.png",
    Producto: "Rocklet Spot",
    Precio: 3100,
    Calorias: "170",
    Descripcion:"Cookie con base de vainilla dulce, rellena con crema suave de frutilla y decorada con rocklets",
},
{
        id: 4,
                Imagen:"/img/cookies-index.jpeg",
    Producto: "Bite & Bake",
    Precio: 3400,
    Calorias: 180,
    Descripcion: "Mini cookies crocantes ideales para picar, con masa de manteca tostada y toques de sal marina y caramelo",
},
{
        id: 5,
        Imagen: "/img/Screenshot 2024-10-21 194508.png",
    Producto: "Red Velvet Crumbs",
    Precio: 3500,
    Calorias: 190,
    Descripcion: "Cookie blandita que se derrite en la boca, clasica red velvet y pedacitos de chocolate blanco",
}
];
// <--------------------------------------------------------------------------------------------------------------------------------->

// Carrito
let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

// Contenedor productos y botón carrito
const contenedorProductos = document.getElementById("contenedorProductos");
const botonCarrito = document.getElementById("botonCarrito");

// Función contador
function actualizarContadorCarrito() {
    let totalCantidad = carrito.reduce((acc, p) => acc + p.cantidad, 0);
    botonCarrito.innerHTML = `<img src="img/carrito.png" alt="Carrito"> Carrito (${totalCantidad})`;
}

actualizarContadorCarrito();

// Mostrar productos
menuDeCookies.forEach(cookie => {
    const tarjeta = document.createElement("div");
    tarjeta.className = "tarjetaProducto";

    tarjeta.innerHTML = `
        <h3>${cookie.Producto}</h3>
        <img src="${cookie.Imagen}" alt="${cookie.Producto}">
        <p>${cookie.Descripcion}</p>
        <b>$${cookie.Precio}</b>
    `;

    const botonAgregar = document.createElement("button");
    botonAgregar.textContent = "Agregar al carrito";
    botonAgregar.onclick = () => {
        let prod = carrito.find(p => p.id === cookie.id);
        if (prod) {
            if (prod.cantidad < 5) prod.cantidad++;
            else alert("No se pueden agregar más de 5 unidades de este producto");
        } else {
            carrito.push({...cookie, cantidad:1});
        }
        localStorage.setItem("carrito", JSON.stringify(carrito));
        actualizarContadorCarrito();
    };

    tarjeta.appendChild(botonAgregar);
    contenedorProductos.appendChild(tarjeta);
});

// Ir al carrito
botonCarrito.onclick = () => window.location.href = "carrito.html";




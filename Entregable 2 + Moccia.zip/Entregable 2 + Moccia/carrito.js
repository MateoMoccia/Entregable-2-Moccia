let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
const contenedorCarrito = document.getElementById("contenedorCarrito");

// Función para mostrar el carrito
function mostrarCarrito() {
    contenedorCarrito.innerHTML = "";
    let total = 0;

    carrito.forEach((producto, index) => {
        const item = document.createElement("p");
        item.textContent = `${producto.Producto} - $${producto.Precio} x ${producto.cantidad}`;

        // Botones + y - para aumentar/disminuir cantidad
        const botonMas = document.createElement("button");
        botonMas.textContent = "+";
        botonMas.onclick = () => {
            if (producto.cantidad < 5) producto.cantidad++;
            localStorage.setItem("carrito", JSON.stringify(carrito));
            mostrarCarrito();
        };

        const botonMenos = document.createElement("button");
        botonMenos.textContent = "-";
        botonMenos.onclick = () => {
            producto.cantidad--;
            if (producto.cantidad <= 0) carrito.splice(index, 1);
            localStorage.setItem("carrito", JSON.stringify(carrito));
            mostrarCarrito();
        };

        item.appendChild(botonMas);
        item.appendChild(botonMenos);

        contenedorCarrito.appendChild(item);

        total += producto.Precio * producto.cantidad;
    });

    const totalP = document.createElement("p");
    totalP.innerHTML = `<b>Total: $${total}</b>`;
    contenedorCarrito.appendChild(totalP);
}

// Botón vaciar carrito
document.getElementById("vaciarCarrito").onclick = () => {
    carrito = [];
    localStorage.setItem("carrito", JSON.stringify(carrito));
    mostrarCarrito();
};

// Botón volver al inicio
document.getElementById("volverInicio").onclick = () => {
    window.location.href = "index.html";
};

// Mostrar carrito inicial
mostrarCarrito();

//ARRAY DE PRODUCTOS//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const productos = [
  {
    Id: 1,
    Producto: "Clasic One",
    Precio: 3000,
    Imagen: "/img/clasic-one.png" ,
    Descripcion: "Clásica y crujiente, con un sabor equilibrado que recuerda a la auténtica cookie casera, perfecta para cualquier momento del día."
  },
  {
    Id: 2,
    Producto: "Choco Mood",
    Precio: 3000,
    Imagen: "/img/choco-mood.png" ,
    Descripcion: "Repleta de trozos de chocolate intenso, cada mordida es una explosión de sabor para los amantes del chocolate que buscan un momento dulce único."
  },
  {
    Id: 3,
    Producto: "Sugar Spot",
    Precio: 3100,
    Imagen: "/img/sugar-spot.png" ,
    Descripcion: "Delicada y dulce, con chispas de azúcar que se funden en la boca, una cookie que combina textura suave y sabor delicioso en cada bocado."
  },
  {
    Id: 4,
    Producto: "Red Velvet",
    Precio: 3200,
    Imagen: "/img/red-velvet.png" ,
    Descripcion: "Suave y aterciopelada, con un sabor delicado y un toque de cacao que la hace irresistible, ideal para quienes buscan un placer sofisticado."
  },
  {
    Id: 5,
    Producto: "Choco Crunch",
    Precio: 3300,
    Imagen: "/img/choco-crunch.png" ,
    Descripcion: "Deliciosa combinación de chocolate y trocitos crujientes que explotan en cada mordida, perfecta para los más golosos."
  },
  {
    Id: 6,
    Producto: "Nutty Delight",
    Precio: 3400,
    Imagen: "/img/nutty-delight.png" ,
    Descripcion: "Repleta de nueces tostadas y sabor auténtico, cada mordida combina textura y dulzura en equilibrio perfecto."
  },
  {
    Id: 7,
    Producto: "Caramel Kiss",
    Precio: 3500,
    Imagen: "/img/caramel-kiss.png" ,
    Descripcion: "Suave y dulce, con centro de caramelo que se derrite lentamente, ideal para quienes disfrutan de un toque gourmet."
  },
  {
    Id: 8,
    Producto: "Berry Bliss",
    Precio: 3400,
    Imagen: "/img/berry-blis.png" ,
    Descripcion: "Frutos rojos naturales y masa esponjosa se unen en una explosión de sabor frutal que hace cada bocado inolvidable."
  }
];
// CARRITO
let carrito = []

//TOTAL//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const totalCompraSpan = document.getElementById("total-compra-numero")

function actualizarTotal() {
  let total = 0
  carrito.forEach(prod => {
    total += prod.Precio * prod.cantidad
  })
  totalCompraSpan.textContent = total.toLocaleString("es-AR") // muestra con formato AR
}

// FUNCION ACTUALIZAR CONTADOR
function actualizarContadorCarrito() {
  const contador = document.getElementById("contador-carrito")
  const total = carrito.reduce((acc, prod) => acc + prod.cantidad, 0)
  contador.textContent = total
}

// ABRIR Y CERRAR CARRITO
const sidebar = document.getElementById("sidebar-carrito");
const overlay = document.getElementById("overlay");
const btnCarrito = document.getElementById("btn-carrito");
const btnCerrar = document.getElementById("cerrar-sidebar");
const btnVaciar = document.getElementById("vaciar-carrito");
const itemsCarrito = document.getElementById("items-carrito");

btnCarrito.addEventListener("click", e => {
  e.preventDefault()
  sidebar.classList.add("active")
  overlay.classList.add("active")
})

btnCerrar.addEventListener("click", () => {
  sidebar.classList.remove("active")
  overlay.classList.remove("active")
})

overlay.addEventListener("click", () => {
  sidebar.classList.remove("active")
  overlay.classList.remove("active")
})

// Vaciar carrito
btnVaciar.addEventListener("click", () => {
  carrito = []
  actualizarContadorCarrito()
  renderCarrito()
})

// FUNCION AGREGAR AL CARRITO
function agregarAlCarrito(id, cantidad) {
  const producto = productos.find(p => p.Id === id)
  if (!producto || cantidad <= 0) return

  const existente = carrito.find(p => p.Id === id)
  if (existente) {
    existente.cantidad += cantidad
  } else {
    carrito.push({ ...producto, cantidad })
  }

  actualizarContadorCarrito()
  renderCarrito()
}

// FUNCION RENDER CARRITO
function renderCarrito() {
  itemsCarrito.innerHTML = ""
  carrito.forEach(prod => {
    const item = document.createElement("div")
    item.classList.add("item-carrito")
    item.innerHTML = `
      <div class="item-carrito-contenido">
        <img src="${prod.Imagen}" alt="${prod.Producto}" class="item-carrito-img">
        <p>${prod.Producto} x${prod.cantidad}</p>
        <p>$${prod.Precio * prod.cantidad}</p>
      </div>
    `
    itemsCarrito.appendChild(item)
  })
}

// CREAR TARJETAS DE PRODUCTOS
const contenedor = document.getElementById("contenedor-de-cookies")

productos.forEach(producto => {
  const tarjeta = document.createElement("div")
  tarjeta.classList.add("tarjeta")

  tarjeta.innerHTML = `
    <p class="letra-boxes">${producto.Producto}</p>
    <img src="${producto.Imagen}" alt="${producto.Producto}">
    <p>${producto.Descripcion}</p>
    <h3>Precio: ${producto.Precio}</h3>
    <div class="box-mas-menos">
      <button class="btn-menos">-</button>
      <span class="cantidad">0</span>
      <button class="btn-mas">+</button>
    </div>
    <button class="btn-agregar">Agregar al carrito</button>
  `

  const spanCantidad = tarjeta.querySelector(".cantidad")
  const btnMas = tarjeta.querySelector(".btn-mas")
  const btnMenos = tarjeta.querySelector(".btn-menos")
  const btnAgregar = tarjeta.querySelector(".btn-agregar")

  btnMas.addEventListener("click", () => {
    let cant = Number(spanCantidad.textContent)
    if (cant < 5) spanCantidad.textContent = cant + 1
  })

  btnMenos.addEventListener("click", () => {
    let cant = Number(spanCantidad.textContent)
    if (cant > 0) spanCantidad.textContent = cant - 1
  })

  btnAgregar.addEventListener("click", () => {
    const cant = Number(spanCantidad.textContent)
    if (cant > 0) {
      agregarAlCarrito(producto.Id, cant)
      spanCantidad.textContent = "0" 
      actualizarTotal()
    }
  })

  contenedor.appendChild(tarjeta)
})


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("form-checkout");

    if (!form) return; 

    form.addEventListener("submit", function(e) {
        e.preventDefault(); 

        const nombre = document.getElementById("nombre").value.trim();
        const email = document.getElementById("email").value.trim();
        const metodoPago = document.getElementById("metodo-pago").value;

        if (!nombre || !email || !metodoPago) {
            alert("Por favor completa todos los campos antes de confirmar la compra.");
            return;
        }

     
        carrito = [];
        actualizarContadorCarrito();
        renderCarrito();

        
window.location.href = "/index.html"; 
    });
});
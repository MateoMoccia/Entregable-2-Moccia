// let variable = "cambiante"

// const constante = "no cambiante"





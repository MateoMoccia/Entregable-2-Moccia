// let variable = "cambiante"

// const constante = "no cambiante"


alert ("Bienvenido a nuestra tienda de cookies")
// <----------------------------------------------------------------->
const nombreDelUsuario = prompt ("Como te llamas?")
console.log(nombreDelUsuario);
const menuDeCookies = [
{
    Producto: "Clasic one",
    Precio: 3000,
    Calorias:"150",
    Descripcion: "Cookie dorada de vainilla con chips de chocolate semiamargo, receta tradicional americana",
},
{
    Producto: "ChocoMood",
    Precio: 3200,
    Calorias: "200",
    Descripcion: "Masa de chocolate, chips de chocolate con leche y centro de Nutella fundida",
},
{
    Producto: "Sugar Spot",
    Precio: 3100,
    Calorias: "170",
    Descripcion:"Cookie con base de vainilla dulce, rellena con crema suave de frutilla y decorada con azúcar glas",
},
{
    Producto: "Bite & Bake",
    Precio: 3400,
    Calorias: 180,
    Descripcion: "Mini cookies crocantes ideales para picar, con masa de manteca tostada y toques de sal marina y caramelo",
},
{
    Producto: "Melted Crumbs",
    Precio: 3500,
    Calorias: 190,
    Descripcion: "Cookie blandita que se derrite en la boca, con masa de manteca avellanada y pedacitos de chocolate",
}
];
// <--------------------------------------------------------------------------------------------------------------------------------->

function generarTextoMenu (menuDeCookies) {
      let textoMenu = "";

for (let i = 0; i < menuDeCookies.length; i++ ) {
    let c = menuDeCookies [i]
    textoMenu += `${i + 1}. ${c.Producto} - $${c.Precio} - ${c.Calorias} cal\n ${c.Descripcion}\n\n`
};

textoMenu += "Elegí una opción (1 al 5):";
return textoMenu
};
// <----------------------------------------------------------------------------------------------------------------->

const textoMenu = generarTextoMenu (menuDeCookies);


let menuEleccionPrompt = prompt ("Bienvenido "+ nombreDelUsuario + ", a continuacion le mostramos nuestro menu para que elija su opcion del dia de hoy:\n\n" + textoMenu);

menuEleccionPrompt = Number (menuEleccionPrompt)
// <--------------------------------------------------------------------------------------------------------------------------------->

let nombreProducto = "";
let precioProducto = 0;


    if (!isNaN(menuEleccionPrompt) && menuEleccionPrompt >= 1 && menuEleccionPrompt <= menuDeCookies.length) {
         switch (menuEleccionPrompt) {
case 1:
nombreProducto = menuDeCookies[0].Producto;
precioProducto = menuDeCookies[0].Precio;
console.log(nombreProducto + precioProducto)
break;

case 2:
nombreProducto = menuDeCookies[1].Producto;
precioProducto = menuDeCookies[1].Precio;
console.log(nombreProducto + precioProducto)
break;

case 3:
nombreProducto = menuDeCookies[2].Producto;
precioProducto = menuDeCookies[2].Precio;
console.log(nombreProducto + precioProducto)
break;

case 4:
nombreProducto = menuDeCookies[3].Producto;
precioProducto = menuDeCookies[3].Precio;
console.log(nombreProducto + precioProducto)
break;

case 5:
nombreProducto = menuDeCookies[4].Producto;
precioProducto = menuDeCookies[4].Precio;
console.log(nombreProducto + precioProducto)
break;

default : 
console.warn("Opcion Invalida");
break;

};
   
}
else {
      alert ("Valor introducido incorrectamente,numero de opcion inexistente")
console.log( "Error, valor invalido");
return
}
    // <------------------------------------------------------------------------------------------------------------------------------------------------->

function pedirCantidad () {
    let cantidad = prompt ("Porfavor seleccione la cantidad de cookies que desea")
    cantidad = Number (cantidad);
     if (isNaN(cantidad) || cantidad <= 0) {
    alert ("Valor introducido incorrectamente")
console.log( "Error, valor invalido");
return false;
     }

console.log(cantidad);
return cantidad; 
};
    // <------------------------------------------------------------------------------------------------------------------------------------------------->

function calcularTotal (cantidad, precioProducto){
return cantidad * precioProducto;
};
    // <------------------------------------------------------------------------------------------------------------------------------------------------->

 let cantidad = pedirCantidad ();
 if (cantidad !== false){
    const total = calcularTotal (cantidad, precioProducto)
alert (`Bueno ${nombreDelUsuario} entonces seria: ${cantidad} x ${nombreProducto}, esto nos daria un total de $${total}`);
 }
else {
    alert ("No pudimos procesar el pedido por una cantidad invalida")
    return
};






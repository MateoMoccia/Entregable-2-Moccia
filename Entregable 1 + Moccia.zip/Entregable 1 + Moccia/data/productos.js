// const cookies = [
//     {
//     id:1,
//     nombre:"Clasic one",
//     precio: 3000,
//     categoria:"cookies",
//     descripcion:"cookie dorada de vainilla con chips de chocolate semiamargo, receta tradicional americana",
//     stock: 10
//     },

//      {
//     id:2,
//     nombre:"ChocoMood",
//     precio: 3200,
//     categoria:"cookies",
//     descripcion:"masa de chocolate, chips de chocolate con leche y centro de Nutella fundida",
//     stock: 10
//     },

//      {
//     id:3,
//     nombre:"Sugar Spot",
//     precio: 3100,
//     categoria:"cookies",
//     descripcion:"cookie con base de vainilla dulce, rellena con crema suave de frutilla y decorada con azúcar glas",
//     stock: 10
//     },

//      {
//     id:4,
//     nombre:"Bite & Bake",
//     precio: 3500,
//     categoria:"cookies",
//     descripcion:"mini cookies crocantes ideales para picar, con masa de manteca tostada y toques de sal marina y caramelo",
//     stock: 10
//     },

//      {
//     id:5,
//     nombre:"Melted Crumbs",
//     precio: 3100,
//     categoria:"cookies",
//     descripcion:"cookie blandita que se derrite en la boca, con masa de manteca avellanada y pedacitos de chocolate",
//     stock: 10
//     },

// ]


// Esto es un array que voy a usar a futuro en el proyecto, a medida que vayamos avanzando con la pagina, 
// basicamente este array si contiene id para luego utilizar en una funcion de carrito, detalles,etc

Este proyecto es un simulador básico de una tienda de cookies artesanales, desarrollado en JavaScript puro, con interacción vía ventanas emergentes (prompt, alert). 
El usuario puede elegir entre distintas opciones de productos, seleccionar la cantidad deseada, y ver el total a pagar.

Contenido del proyecto:

index.html
Página principal con estructura básica y referencias al archivo de estilos y el script JavaScript.

app.js
Código JavaScript que contiene la lógica del simulador:

Muestra un menú con las cookies disponibles.

Solicita el nombre del usuario.

Permite seleccionar una opción válida del menú.

Solicita la cantidad deseada y calcula el total.

Muestra mensajes claros y controles de errores.

productos.js 
(es un array que sera utilizado a futuro)


Funcionalidades principales:
-Uso de arrays para almacenar los productos con sus atributos.

-Funciones para generar el menú, pedir opciones y cantidades, validar entradas y calcular totales.

-Uso de condicionales (if, switch) para controlar la lógica del simulador.

-Interacción con el usuario mediante prompt y alert.

-Validación básica de entradas para evitar errores.



Mateo Moccia/ 17 años